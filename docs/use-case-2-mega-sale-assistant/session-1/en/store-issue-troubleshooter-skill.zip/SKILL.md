---
name: store-issue-troubleshooter
description: Gives store teams a step-by-step procedure for a Mega Sale store
  problem, such as a discount not applied at checkout, a wrong price label,
  an out-of-stock promoted item or a display problem. Use when someone asks
  what to do about a problem in store.
---

# Store issue troubleshooter

## Steps
1. Identify the issue type using issue-types.md. If it isn't clear, ask one
   short question.
2. Find the procedure in the document listed for that issue type.
3. Answer using the format below. Don't skip or rename any heading.

## Format
**Issue:** <one line>

**🛠️ What to do now**
1. <most urgent step>
2. <next step>

**✅ Who approves:** <approver, or "No approval needed">

**📣 Escalate if:** <when and to whom, or "Not covered in the documents –
ask your Area Manager">

**Source:** <document name> – <section>

## Rules
- Use only the Mega Sale documents. Never invent approval codes, phone
  numbers or names.
- Keep the answer under 120 words so it can be read at the till.
