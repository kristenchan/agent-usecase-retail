| Issue type | Examples | Where to look |
|---|---|---|
| Discount not applied | Sale price not showing at the till | Store Execution Guide – Checkout; Mega Sale Playbook – Discount rules |
| Price label error | Label and till price don't match | Store Execution Guide – Price labels |
| Out-of-stock promoted item | Promoted product sold out | Store Execution Guide – Out of stock |
| Display problem | Display not ready, materials missing | Store Execution Guide – Displays |
| Coupon or points problem | E-coupon rejected, points missing | Mega Sale Playbook – Tailwind Rewards; Mega Sale FAQ |
