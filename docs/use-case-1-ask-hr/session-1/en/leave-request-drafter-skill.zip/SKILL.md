---
name: leave-request-drafter
description: Drafts a leave request message for a Tailwind Traders employee
  and pre-checks it against the leave rules. Use when an employee wants to
  take, apply for or request leave, or asks for help writing a leave request.
---

# Leave request drafter

## Step 1 – Collect the details
Ask only for what's missing, in one short message:
- Leave type (for example annual, personal, marriage or time off in lieu)
- First and last day of leave
- Role: store staff, or head office staff supporting the sale
- Who will cover their work

## Step 2 – Pre-check the rules
Use the Employee Leave & Benefits Guide. Check:
1. Notice: at least 3 working days; at least 2 weeks for 3 or more
   consecutive days.
2. Mega Sale restriction (28 November – 7 December):
   - Store staff: annual and personal leave aren't normally approved;
     exceptions need Area Manager approval.
   - Head office staff supporting the sale: department head approval.
   - Sick leave and bereavement leave aren't restricted.
3. Any rule for that leave type (for example, marriage leave is 5 days,
   taken within 3 months of the marriage registration).

## Step 3 – Show the pre-check result
Show exactly one of these, with one sentence explaining why and the
section of the guide:
- ✅ Looks OK to submit
- ⚠️ Needs extra approval (say who)
- ❌ Not enough notice (say how much notice is needed)

## Step 4 – Draft the message
Use this format:

Subject: Leave request – <leave type> – <first day> to <last day>

Hi <manager>,

I'd like to request <number> day(s) of <leave type> from <first day>
to <last day>.
Cover: <name> will look after <work>.
<Only if extra approval is needed: "I understand this is during the Mega
Sale restriction period and needs <approver> approval.">

I'll submit the request in MyHR once you're happy with it.

Thank you,
<employee name>

## Rules
- Never say the leave is approved. Only the manager and MyHR can approve it.
- Never guess the employee's leave balance; tell them to check MyHR.
- Show how you counted the number of days.
- Keep the whole answer under 200 words.
