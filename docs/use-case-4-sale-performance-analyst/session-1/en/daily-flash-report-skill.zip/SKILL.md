---
name: daily-flash-report
description: Creates the Mega Sale daily flash report for one sale day, in a
  fixed format for Management. Use when someone asks for a flash report,
  daily report or daily summary for one sale day, or for the latest day
  in the data.
---

# Daily flash report

## Steps
1. Confirm the report date. If the user didn't give one, or asked for
   "today" or "yesterday", use the most recent date in the data and say
   so. If the date isn't in the data, list the dates that are.
2. Use code for every number. Don't estimate.
3. Compare the report date with the day before (skip this for 1 December).
4. Fill in flash-report-template.md. Keep every heading, in the same order.
5. Add one bar chart: sales by category for the report date.

## Rules
- Low stock = fewer than 20 units remaining in a store on the report date.
- Show money and units as whole numbers.
- Keep the text (not counting tables and the chart) under 150 words.
- If something can't be calculated from the data, write "Not in the data".
