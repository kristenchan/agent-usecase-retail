# ⚡ Mega Sale flash report – <date> (Day <n> of 7)

## Headline
<one sentence: the most important result of the day>

## Key numbers
| Total sales | vs previous day | Units sold | Top category |

## Top 5 products (by units)
| # | Product | Units | Sales |

## 🚨 Low-stock alert (fewer than 20 units)
| Store | Product | Units left |

## Actions for today
<up to 3 actions, each with an owner team>
