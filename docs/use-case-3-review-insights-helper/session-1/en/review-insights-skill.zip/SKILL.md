---
name: review-insights
description: Classifies Mega Sale customer reviews into themes and priorities,
  and creates the Mega Sale review report. Use when someone asks what needs
  attention, asks for the top issues or safety concerns, or asks for a
  review report or summary for leadership.
---

# Review insights

## Task A – What needs attention
1. Classify every review using classification-rules.md.
2. Use code to count reviews and calculate the average rating for each
   theme. Don't estimate.
3. Rank themes by impact: number of reviews x (5 - average rating).
4. Show the top 3 in a table: theme, reviews, average rating, example
   comment, owner team.

## Task B – Review report
1. Use every review in the data. The date range is the first to the last
   review date in the data, not today's date. Do steps 1–3 of Task A.
2. Fill in weekly-report-template.md. Keep every heading, in the same order.
3. Add one chart: average rating by day.

## Always
- List every health and safety review in a separate section called
  "⚠️ Health & safety – escalate", even if the user didn't ask.
- Never try to identify customers. Never judge individual employees.
