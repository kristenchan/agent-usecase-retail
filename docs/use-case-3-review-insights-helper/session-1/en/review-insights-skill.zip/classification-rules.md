| Theme | Keywords and signals | Owner team |
|---|---|---|
| ⚠️ Health & safety | irritation, rash, allergy, burning, itchy, injury | Quality (always first) |
| Price & discounts | price label, wrong price, discount not applied | Store Operations + Trading |
| Checkout & queues | queue, waiting, slow checkout, till | Store Operations |
| Product quality | leaking, broken, damaged, expired | Trading & Merchandising |
| Stock | sold out, out of stock, not available | Trading & Merchandising |
| Staff service | rude, helpful, friendly staff | Store Operations |
| Value & bundles | bundle, value, good deal | Marketing |

Rules:
- A review can have more than one theme.
- If a review mentions any health & safety keyword, it is ALWAYS in the
  Health & safety theme, even if the rating is high.
