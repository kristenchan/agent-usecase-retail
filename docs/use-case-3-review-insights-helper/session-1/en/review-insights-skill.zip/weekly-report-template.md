# Mega Sale review report – <date range>

## 1. Headline
<one sentence>

## 2. Key numbers
| Total reviews | Average rating | 4–5 stars | 1–2 stars |

## 3. ⚠️ Health & safety – escalate
<every review with a health or safety signal, or "None in this period">

## 4. Top 3 issues
| Theme | Reviews | Average rating | Example comment | Owner team |

## 5. What customers loved
<top 2 themes with an example comment>

## 6. Recommended actions
<up to 5 actions, each with an owner team>
